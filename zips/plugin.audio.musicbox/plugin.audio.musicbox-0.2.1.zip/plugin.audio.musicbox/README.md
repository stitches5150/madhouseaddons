plugin.audio.musicbox
=====================

Music box is a new way to listen and discover music thought KODI (former XBMC)

Addon Repository: [repository.techdealer-1.3.zip](https://git.io/vMVxL)
